public class Main {

    public static void main(String[] args) {
        String in = "462*823-61-263+518*490*479+851+276+13-208-418-537+486+476+15*227-274";
        ArithmeticExpressionEvaluator test = new ArithmeticExpressionEvaluator(in);
        System.out.println(test);
    }

}
