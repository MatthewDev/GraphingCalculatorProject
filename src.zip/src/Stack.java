/**
 * Created by Matthew on 9/12/2016.
 */
public class Stack<E> {
    private Node<E> head = null;
    public void push(E obj){
        Node<E> newNode = new Node<E>(obj);
        if(head==null){
            head = newNode;
        }else{
            newNode.next = head;
            head = newNode;
        }
    }
    public E peek(){
        if(isEmpty()) return null;
        return head.obj;
    }
    public E pop(){
        if(isEmpty()) return null;
        E val = head.obj;
        head = head.next;
        return val;
    }
    public boolean isEmpty(){
        if(head == null) return true;
        return false;
    }

    private class Node<E> {
        E obj;
        Node<E> next = null;

        public Node(E obj) {
            this.obj = obj;
        }
    }


}
