import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

/**
 * Created by Matthew on 9/12/2016.
 */
public class InfixToPostfix {
    private String infix, originalInfix, postfix;
    private static HashMap<Character, Integer> precedence = new HashMap<Character, Integer>(){{ //<- generally not advised, but its a constant
        put('(', -99);//lowest precedence
        put('^', -2);//e
        put('*', -3);//md
        put('/', -3);
        put('+', -4);//as
        put('-', -4);
    }};
    public InfixToPostfix(String infix){
        this.originalInfix = infix;
        this.infix = infix.replace(" ", ""); //delete spaces
        evaluate();
    }
    private void evaluate(){
        Stack<Character> operatorStack = new Stack<>();
        StringBuilder sb = new StringBuilder();
        String[] split = infix.split("(?<=[^0-9])|(?=[^0-9])"); //regex splits out operators
        Pattern number = Pattern.compile("[0-9]+");

        for(String s : split){
            if(number.matcher(s).matches()){ //if numeric
                 sb.append(s+" ");
            }else{
                char curOperator = s.charAt(0);
                if(curOperator=='('){
                    operatorStack.push(curOperator);
                }else if(curOperator==')'){
                    while(operatorStack.peek()!='('){
                        sb.append(operatorStack.pop()+" ");
                    }
                    operatorStack.pop(); //dispose of parenthesis pair
                }else if(operatorStack.isEmpty()){
                    operatorStack.push(curOperator);
                }else{
                    //System.out.println(curOperator+" "+operatorStack.peek());
                    if(isHigher(curOperator, operatorStack.peek())){
                        operatorStack.push(curOperator);
                    }else if(isLower(curOperator, operatorStack.peek())){
                        while(!operatorStack.isEmpty() && !isHigher(curOperator, operatorStack.peek())){//if equal pop, thus not higher instead of lower
                            sb.append(operatorStack.pop()+" ");
                        }
                        operatorStack.push(curOperator);
                    }else{ //equal precedence, left to right, so pop left first
                        sb.append(operatorStack.pop()+" ");
                        operatorStack.push(curOperator);
                    }
                }
            }
        }
        while(!operatorStack.isEmpty()){
            sb.append(operatorStack.pop()+" ");
        }
        sb.deleteCharAt(sb.length()-1);
        postfix = sb.toString();
    }
    private static boolean isHigher(char a, char b){
        return precedence.get(a)>precedence.get(b);
    }
    private static boolean isLower(char a, char b){
        return precedence.get(a)<precedence.get(b);
    }

    public String getPostfix(){
        return postfix;
    }
    static void dump(String[] arr) {
        for (String s : arr) {
            System.out.format("[%s]", s);
        }
        System.out.println();
    }


}
