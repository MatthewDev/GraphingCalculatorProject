import java.util.regex.Pattern;

/**
 * Created by Matthew on 9/12/2016.
 */
public class EvaluatePostfix {
    private String postfix;
    private long value;

    public EvaluatePostfix(String postfix){
        this.postfix = postfix; //immutable
        value = evaluate();
    }
    private long evaluate(){
        String[] split = postfix.split(" ");
        Pattern number = Pattern.compile("[0-9]+");
        Stack<Long> numbers = new Stack<>();

        for(String s : split){
            if(number.matcher(s).matches()) {
                numbers.push(Long.parseLong(s));
            }else{
                long b = numbers.pop();
                long a = numbers.pop();
                long c = 0;
                switch(s){
                    case "*":
                        c = a*b;
                        break;
                    case "/":
                        c = a/b;
                        break;
                    case "+":
                        c = a+b;
                        break;
                    case "-":
                        c = a-b;
                        break;
                    case "^":
                        c = (long) Math.pow(a, b);
                        break;
                }
                numbers.push(c);
            }
        }
        return numbers.pop();
    }
    @Override
    public String toString(){
        return  "Postfix: "+ getPostfix() +"\n"+
                "Value: "+ getValue() +"\n";
    }

    public String getPostfix() {
        return postfix;
    }

    public long getValue() {
        return value;
    }
}
