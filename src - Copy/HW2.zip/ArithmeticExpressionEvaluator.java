/**
 * Created by Matthew on 9/12/2016.
 */
public class ArithmeticExpressionEvaluator {
    public static void main(String[] args) {
        String infix = "(8 - 1 + 3) * 6 - ((3 + 7) * 2)";
        System.out.println(infix);
        InfixToPostfix converter = new InfixToPostfix(infix);
        EvaluatePostfix test = new EvaluatePostfix(converter.getPostfix());
        System.out.println(test);
    }
}
